So you need to do a couple of things

1. every file in the cef_exe_dir/ directory should be put in the solution directory
2. cef_include_lib_dirs contains the includes and libs, you should put these whereever you are putting your other lib & include files
3. make sure you set up the VC++ directories for the includes and libs.