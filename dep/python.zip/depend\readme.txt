Run Installer

python32_d.lib goes in C:\Python32\libs\

Edit your environment vars (make sure these go before cygwin):

Path C:\Python32;
INCLUDE C:\Python32\include;
LIB C:\Python32\libs;